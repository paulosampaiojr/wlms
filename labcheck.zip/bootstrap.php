<?php
    session_start();
    include __DIR__ . '/vendor/autoload.php';
?>