<div class="row">
    <div class="col-md-3 form-group mb-3 menubutton" id="button-home"><a href="<?=PATH_PAGES?>/index.php">Home</a></div>
    <div class="col-md-3 form-group mb-3 menubutton" id="button-checkout"><a href="#">Vazio</a></div>
    <div class="col-md-3 form-group mb-3 menubutton" id="button-desempenho"><a href="#">Vazio</a></div>
    <div class="col-md-3 form-group mb-3 menubutton" id="button-faleconosco"><a href="#">Vazio</a></div>
</div>