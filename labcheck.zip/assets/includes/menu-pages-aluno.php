<div class="row">
    <div class="col-md-3 form-group mb-3 menubutton" id="button-home"><a href="<?=PATH_PAGES?>/index.php">Home</a></div>
    <div class="col-md-3 form-group mb-3 menubutton" id="button-checkin"><a href="<?=PAGE_ALUNO_VISUALIZAR_CHECKIN?>">Check In</a></div>
    <div class="col-md-3 form-group mb-3 menubutton" id="button-desempenho"><a href="<?=PAGE_ALUNO_VISUALIZAR_CHECKOUT?>">Check Out</a></div>
    <div class="col-md-3 form-group mb-3 menubutton" id="button-faleconosco"><a href="<?=PAGE_ALUNO_VISUALIZAR_HORAS_DE_LABORATORIO?>">Horas de Lab</a></div>
</div>