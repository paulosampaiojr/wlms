<?php

	$servidor = "sql742.main-hosting.eu";
	$usuario = "u970734089_webacademy";
	$senha = "6/fWs:ahW=HS";
	$dbname = "u970734089_webacademy";
	
	//Criar a conexao
	$conn = mysqli_connect($servidor, $usuario, $senha, $dbname);

?>
